create default dbo.df_DateTimeStamp as (getdate())
GO