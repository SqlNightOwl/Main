create default dbo.df_ValueType as ('string')
GO