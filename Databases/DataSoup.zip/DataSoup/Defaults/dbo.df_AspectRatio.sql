create default dbo.df_AspectRatio as (16.9)
GO