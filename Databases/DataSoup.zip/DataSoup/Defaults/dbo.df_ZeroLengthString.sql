create default dbo.df_ZeroLengthString as ('')
GO