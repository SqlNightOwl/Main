create default dbo.df_Zero as (0)
GO