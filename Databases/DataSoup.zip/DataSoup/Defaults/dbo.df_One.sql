create default dbo.df_One as (1)
GO