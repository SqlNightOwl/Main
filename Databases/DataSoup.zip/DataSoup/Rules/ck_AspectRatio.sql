use DataSoup
go
create rule [ck_AspectRatio] as (@value = 16.9 or @value = 4.3)
GO