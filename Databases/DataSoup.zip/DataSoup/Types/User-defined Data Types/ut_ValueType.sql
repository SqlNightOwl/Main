use DataSoup
go
EXEC sp_addtype N'ut_ValueType', N'varchar (8)', N'not null'
GO