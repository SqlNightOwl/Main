use DataSoup
go
EXEC sp_addtype N'ut_AspectRatio', N'decimal(3,1)', N'not null'
GO