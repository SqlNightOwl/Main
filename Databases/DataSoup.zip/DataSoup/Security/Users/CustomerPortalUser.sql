CREATE USER [CustomerPortalUser] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[customerportaluser]
GO
